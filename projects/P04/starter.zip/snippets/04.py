def safe_int(text):
    try:
        return int(text)
    except ValueError:
        return 0
