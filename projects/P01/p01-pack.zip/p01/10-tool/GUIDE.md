## missing
This week you build in the browser, so there's nothing to install.
The one choice is which tool: Lovable, or UW Purple if you'd rather
keep your work inside UW. Each has its own one-page handout.

## fix
Lovable: go to lovable.dev and make a free account. No card, ever - if
it asks for payment details, stop and tell course staff.

UW Purple: go to purple.uw.edu and sign in with your NetID. You also
need a GitHub account (github.com, free), because Purple doesn't
publish your app - you push the html file it writes to GitHub yourself.

Then pick "Tell me which tool" and type lovable or purple. I save it
to a private .env file in this folder and open the matching handout.

## passed
Tool chosen. Read the handout that matches it - ASSIGNMENT.md for
Lovable, ASSIGNMENT-PURPLE.md for UW Purple - and start from its
first line.

## model
The choice is stored in .env as P01_TOOL (lovable or purple). Either
value passes; anything else is cleared so the wizard asks again. There
is no local install for this project. Lovable's free tier gives about
three prompts. Purple has no preview toolbar, so its handout swaps the
annotation step for a screenshot of the area to change.

## manual
Choose your tool. Lovable: make a free account at lovable.dev. UW
Purple: sign in at purple.uw.edu with your NetID and make a free
GitHub account at github.com. Open the handout for your tool - the
Project 1 page in Canvas links both.
