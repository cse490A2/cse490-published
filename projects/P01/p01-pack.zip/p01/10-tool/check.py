import json, os, sys
envs = {}
if os.path.exists(".env"):
    for line in open(".env", encoding="utf-8"):
        if "=" in line and not line.strip().startswith("#"):
            k, _, v = line.partition("=")
            envs[k.strip()] = v.strip()
raw = envs.get("P01_TOOL", "")
tool = raw.strip().strip('"').lower().replace("uw ", "")
if not tool:
    print(json.dumps({"detail": "no tool chosen yet"}))
    sys.exit(1)
if tool not in ("lovable", "purple"):
    envs.pop("P01_TOOL", None)
    with open(".env", "w", encoding="utf-8") as f:
        f.write("# Course settings. Private - never commit or share.\n")
        for k, v in envs.items():
            f.write("%s=%s\n" % (k, v))
    print(json.dumps({"detail": "'%s' isn't one of the two - type lovable or purple" % raw}))
    sys.exit(1)
if tool != raw:
    envs["P01_TOOL"] = tool
    with open(".env", "w", encoding="utf-8") as f:
        f.write("# Course settings. Private - never commit or share.\n")
        for k, v in envs.items():
            f.write("%s=%s\n" % (k, v))
handout = "ASSIGNMENT.md" if tool == "lovable" else "ASSIGNMENT-PURPLE.md"
print(json.dumps({"detail": "building with %s - your handout is %s"
                  % ("Lovable" if tool == "lovable" else "UW Purple", handout)}))
sys.exit(0)
