import json, os, sys
need = ["ASSIGNMENT.md", "ASSIGNMENT-PURPLE.md", "SUBMISSION.txt"]
missing = [n for n in need if not os.path.exists(n)]
if missing:
    print(json.dumps({"detail": "missing: " + ", ".join(missing)}))
    sys.exit(1)
print(json.dumps({"detail": "both handouts are in place: ASSIGNMENT.md (Lovable) "
                  "and ASSIGNMENT-PURPLE.md (UW Purple), plus SUBMISSION.txt to fill in"}))
sys.exit(0)
