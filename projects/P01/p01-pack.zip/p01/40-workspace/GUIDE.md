## missing
Your project folder needs its two handouts - I normally place them
myself, so if we're here, something removed them.

## fix
Check again first - I re-seed the files automatically each time. If it
still fails, re-download the project pack and unzip it fresh, then run
me from the new folder.

## passed
Handouts in place: ASSIGNMENT.md is the Lovable version and
ASSIGNMENT-PURPLE.md is the UW Purple version. Read the one for your
tool. SUBMISSION.txt is what you fill in and upload at the end, with
your annotation screenshot. Everything else this week happens in the
browser.

## model
The wizard copies this module's files/ into the project folder before
every check. Both handouts are snapshots of the Project 1 handout docs
and are refreshed from them whenever the pack updates. A persistent
failure means the folder is read-only or the zip was unpacked oddly.

## manual
Read the Project 1 handout for your tool from the Project 1 page in
Canvas, and download SUBMISSION.txt from the Week 1 module. There are
no files to create this week.
