Project 1: Prompt to App
Due: Tuesday 11:59 pm
Turn one written description into a working web app, without writing a line of code.
Build with UW Purple. It runs inside UW, so your prompts and your app stay private. Sign in with your NetID and start a new chat.
Purple doesn't publish for you: ask it for a single html file, save the file, and push it to your GitHub account. If you'd rather have the app published for you, use the Lovable version of this handout instead.
Describe the app you want in one message: that message is your specification, and Purple writes the whole thing. Your job is to open the file in a browser, see what it got right, find what it got wrong, and steer. Pick one:
* A personal landing page: your name, your work, your links, open in any browser.
* A chart maker: paste rows from any spreadsheet, get a chart.
* Rock-paper-scissors: play against the computer, first to three wins.
* Or write your own: something someone would actually use, of comparable scope.
Your app should meet the following requirements:
* The html file is in your GitHub account, opens in a browser, and the app does its job.
* Turn in every prompt you sent, in the order you sent them. The first one is your specification.
* Use annotation at least once: take a screenshot of the part you want changed, and describe the change to Purple. Keep the screenshot; it is part of your turnin.
* Test your app. Write a short testing note: the defect you found and the prompt that fixed it.
* No hand-edited code. Save Purple's file exactly as it wrote it.
Grading
A model will autograde your submission. It reads your submission file and screenshot and checks that each requirement was followed. Every check is pass or fail. It does not judge your app's looks, prompt wording, or how many tries it took.
Turnin
* Fill in SUBMISSION.txt, from the Week 1 module in Canvas or the project pack: the link to your html file on GitHub, your prompts, and your testing note. Upload it and your annotation screenshot to the Project 1 assignment in Canvas.
* Fill out the feedback form.