Project 1: Prompt to App
Due: Tuesday 11:59 pm
Turn one written description into a published web app, without writing a line of code.
Build with Lovable. Lovable’s free tier gives you about three prompts. If you’d rather keep your work inside UW, use the Purple version of this handout instead. You can get started by skimming Welcome to Lovable.


Describe the app you want in one message: that message is your specification, and the platform builds and publishes the whole thing. Your job is to see what it got right, find what it got wrong, and steer. Pick one:
* A personal landing page: your name, your work, your links, live at a real URL.
* A chart maker: paste rows from any spreadsheet, get a chart.
* Rock-paper-scissors: play against the computer, first to three wins.
* Or write your own: something someone would actually use, of comparable scope.


Your app should meet the following requirements:
* The published URL loads without a login and the app does its job.
* Turn in every prompt you sent, in the order you sent them. The first one is your specification.
* Use annotation at least once: in Lovable's preview toolbar, select the part you want changed, or draw on it, and describe the change. Screenshot it; the screenshot is part of your turnin.
* Test your app. Write a short testing note: the defect you found and the prompt that fixed it.
* No hand-edited code.
Grading
A model will autograde your submission. It reads your submission file and screenshot and checks that each requirement was followed. Every check is pass or fail. It does not judge your app's looks, prompt wording, or how many tries it took.
Turnin
* Fill in SUBMISSION.txt, from the Week 1 module in Canvas or the project pack: your published URL, your prompts, and your testing note. Upload it and your annotation screenshot to the Project 1 assignment in Canvas.
* Fill out the feedback form.